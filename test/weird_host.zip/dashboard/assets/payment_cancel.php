<?php
    echo "<h2>Payment Cancelled</h2><a href='../'><h3>Go to Login Page</h3></a>";
?>